package com.example.exercicio_aula_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
